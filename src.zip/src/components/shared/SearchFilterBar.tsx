"use client";
import { Search, Calendar, RefreshCw } from "lucide-react";

interface SearchFilterBarProps {
  searchValue: string;
  onSearchChange: (v: string) => void;
  onSearch: () => void;
  fromDate?: string;
  toDate?: string;
  onFromDateChange?: (v: string) => void;
  onToDateChange?: (v: string) => void;
  onDateSearch?: () => void;
  onClearDates?: () => void;
  placeholder?: string;
}

export default function SearchFilterBar({
  searchValue, onSearchChange, onSearch,
  fromDate, toDate, onFromDateChange, onToDateChange,
  onDateSearch, onClearDates,
  placeholder = "Search Item",
}: SearchFilterBarProps) {
  return (
    <div style={{ marginBottom: 14 }}>
      {/* Search row */}
      <div style={{ display: "flex", gap: 10, marginBottom: 10, alignItems: "center" }}>
        <div style={{ flex: 1, position: "relative" }}>
          <span style={{
            position: "absolute", left: 13, top: "50%", transform: "translateY(-50%)",
            color: "#B0B8C8", pointerEvents: "none", display: "flex",
          }}>
            <Search size={15} />
          </span>
          <input
            type="text"
            value={searchValue}
            onChange={e => onSearchChange(e.target.value)}
            onKeyDown={e => e.key === "Enter" && onSearch()}
            placeholder={placeholder}
            style={{
              width: "100%",
              padding: "11px 14px 11px 38px",
              borderRadius: 999,
              fontFamily: "Nunito, sans-serif",
              fontSize: 14,
            }}
          />
        </div>
        <button
          onClick={onSearch}
          style={{
            background: "var(--primary)",
            color: "white",
            border: "none",
            borderRadius: 999,
            padding: "11px 20px",
            fontFamily: "Nunito, sans-serif",
            fontWeight: 700,
            fontSize: 13,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 6,
            whiteSpace: "nowrap",
            boxShadow: "0 3px 10px rgba(79,70,229,0.25)",
            flexShrink: 0,
          }}
        >
          <Search size={14} /> Search
        </button>
      </div>

      {/* Date filter row */}
      {onFromDateChange && (
        <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "nowrap" }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: "var(--text-secondary)", flexShrink: 0 }}>From</span>

          {/* From date */}
          <div style={{ flex: 1, position: "relative" }}>
            <input
              type="date"
              value={fromDate || ""}
              onChange={e => onFromDateChange?.(e.target.value)}
              style={{
                width: "100%",
                padding: "9px 36px 9px 12px",
                borderRadius: 10,
                fontSize: 13,
                fontFamily: "Nunito, sans-serif",
              }}
            />
            <Calendar size={14} style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)", color: "var(--primary)", pointerEvents: "none" }} />
          </div>

          <span style={{ fontSize: 13, fontWeight: 700, color: "var(--text-secondary)", flexShrink: 0 }}>To</span>

          {/* To date */}
          <div style={{ flex: 1, position: "relative" }}>
            <input
              type="date"
              value={toDate || ""}
              onChange={e => onToDateChange?.(e.target.value)}
              style={{
                width: "100%",
                padding: "9px 36px 9px 12px",
                borderRadius: 10,
                fontSize: 13,
                fontFamily: "Nunito, sans-serif",
              }}
            />
            <Calendar size={14} style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)", color: "var(--primary)", pointerEvents: "none" }} />
          </div>

          {/* Date search button */}
          <button
            onClick={onDateSearch}
            style={{
              width: 38, height: 38, borderRadius: 10,
              background: "var(--primary-pale)",
              border: "1.5px solid var(--primary-muted)",
              display: "flex", alignItems: "center", justifyContent: "center",
              cursor: "pointer", color: "var(--primary)", flexShrink: 0,
            }}
          >
            <Search size={15} />
          </button>

          {/* Clear dates */}
          {(fromDate || toDate) && (
            <button
              onClick={onClearDates}
              title="Clear dates"
              style={{
                width: 38, height: 38, borderRadius: 10,
                background: "#FEF2F2",
                border: "1.5px solid #FECACA",
                display: "flex", alignItems: "center", justifyContent: "center",
                cursor: "pointer", color: "#DC2626", flexShrink: 0,
              }}
            >
              <RefreshCw size={15} />
            </button>
          )}
        </div>
      )}
    </div>
  );
}
